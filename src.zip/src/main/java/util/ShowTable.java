package util;

import java.util.List;

import model.Account;
import model.Porder;
import model.Product;
import service.impl.AccountServiceImpl;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;

public class ShowTable {

	public static String[][] queryAccount(String userName )
	{
		//String[][] show=null;
		List<Account> list;
		if(userName==null)
			list = new AccountServiceImpl().selectAll();
		else
			list= new AccountServiceImpl().selectByUserNameList(userName);
		String[][] show = new String[list.size()][5];
		Tool.saveFile(list, "accountQuery.txt");
		int i=0;
		for(Account a:list)
		{
			//show=show+"\n"+a.getNo()+"\t"+a.getName()+"    \t"+a.getId()+"    \t"+a.getPassword()+"    \t"+a.getLevel();
			show[i][0] = a.getId()+"";
			show[i][1] = a.getName();
			show[i][2] = a.getUserName();
			show[i][3] = a.getPassword();
			show[i][4] = a.getLevel();
			i++;
			System.out.println(a.getId());
		}
		
		return show;
	}
	
	public static String[][] queryProduct(String productNo )
	{
		System.out.println(productNo);
		//String[][] show=null;
		//List<Porduct> list;
		List<Product> list;
		if(productNo==null)
			list = new ProductServiceImpl().selectAll();
		else
			list= new ProductServiceImpl().selectByPorductNoList(productNo);
		
		Tool.saveFile(list, "productQuery.txt");
		String[][] show = new String[list.size()][4];
		int i=0;
		for(Product p:list)
		{
			//show=show+"\n"+a.getNo()+"\t"+a.getName()+"    \t"+a.getId()+"    \t"+a.getPassword()+"    \t"+a.getLevel();
			show[i][0] = p.getId()+"";
			show[i][1] = p.getProductNo();
			show[i][2] = p.getProductName();
			show[i][3] = p.getPrice()+"";
			i++;
			
		}
		
		return show;
	}
	
	public static String[][] queryPorder(String userName, String porderNo)
	{
		//System.out.println(porderNo);
		//String[][] show=null;
		//List<Porduct> list;
		List<Porder> list;
		if(userName==null && porderNo==null)
			list = new PorderServiceImpl().selectPorderAll();
		else
			list= new PorderServiceImpl().selectByNo(userName, porderNo);
		
		Tool.saveFile(list, "porderQuery.txt");
		String[][] show = new String[list.size()][4];
		int i=0;
		for(Porder p:list)
		{
			//show=show+"\n"+a.getNo()+"\t"+a.getName()+"    \t"+a.getId()+"    \t"+a.getPassword()+"    \t"+a.getLevel();
			show[i][0] = p.getId()+"";
			show[i][1] = p.getPorderNo();
			show[i][2] = p.getUserName();
			show[i][3] = new AccountServiceImpl().selectGetName(p.getUserName());
			i++;
			
		}
		
		return show;
	}
	
	public static String[][] queryPorderDetail(String porderNo)
	{
		System.out.println("queryPorderDetail->"+porderNo);
		//String[][] show=null;
		//List<Porduct> list;
		List<Porder>	list= new PorderServiceImpl().selectPorderDetailAll(porderNo);
		
		Tool.saveFile(list, "porderDetailQuery.txt");
		String[][] show = new String[list.size()][5];
		int i=0;
		for(Porder p:list)
		{
			//show=show+"\n"+a.getNo()+"\t"+a.getName()+"    \t"+a.getId()+"    \t"+a.getPassword()+"    \t"+a.getLevel();
			show[i][0] = i+1+"";
			show[i][1] = p.getProductNo();
			show[i][2] = new ProductServiceImpl().selectByPorductNo(p.getProductNo()).getProductName();
			show[i][3] = p.getAmount()+"";
			show[i][4] = ((int)new ProductServiceImpl().selectByPorductNo(p.getProductNo()).getPrice()*p.getAmount())+"";
			i++;
			
		}
		
		return show;
	}
}
