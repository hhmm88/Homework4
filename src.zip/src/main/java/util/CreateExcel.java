package util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import model.Account;
import model.Porder;
import service.impl.AccountServiceImpl;

public class CreateExcel {

	static HSSFSheet sheet;// = null;
    HSSFWorkbook excelbook=new HSSFWorkbook();
    
    public void create(String FileName,String sheetName,String[] titleName)
    {
    	try {
			FileOutputStream out = new FileOutputStream(FileName);
			
			 sheet = excelbook.createSheet(sheetName);
			 HSSFRow row = sheet.createRow((short) 0);
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	          }
			 excelbook.write(out);
			 out.flush();
			 out.close(); 
			 
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public boolean createAccountAll(String fileName,String sheetName)
    {
    	boolean export = false;
    	try {
			FileOutputStream out = new FileOutputStream(fileName);
			
			 sheet = excelbook.createSheet(sheetName);
			 int count = 0;
			 HSSFRow row = sheet.createRow((short) count);
			 String[] titleName=new String[] {"No","ID","Name","UserName","Password","Level"};
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	          }
			 List<Account> accountList = new AccountServiceImpl().selectAll();
	            for(Account o:accountList )
	            {
	            	count++; 
			        
			        row = sheet.createRow((short) count); 
			        
			        row.createCell((short) 0).setCellValue(o.getId()); 
			        row.createCell((short) 1).setCellValue(o.getName()); 
			        row.createCell((short) 2).setCellValue(o.getUserName()); 
			        row.createCell((short) 3).setCellValue(o.getPassword()); 
			        row.createCell((short) 4).setCellValue(o.getLevel()); 
			        
	            }

		        excelbook.write(out);// 把對應的Excel工作簿存碟
		        out.flush();
		        out.close(); 
		        export=true;
			    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return export;
    }
    
    public void insertAccountValue(Account account,String fileName,String sheetName)
    {
    	try {
			excelbook = new HSSFWorkbook(new FileInputStream(fileName));
			HSSFSheet sheet = excelbook.getSheet(sheetName);        //獲得指定的工作表
	        int count = sheet.getPhysicalNumberOfRows();  
	        
	        HSSFRow row = sheet.createRow((short) count); 
	        
	        row.createCell((short) 0).setCellValue(account.getId()); 
	        row.createCell((short) 1).setCellValue(account.getName()); 
	        row.createCell((short) 2).setCellValue(account.getUserName()); 
	        row.createCell((short) 3).setCellValue(account.getPassword()); 
	        row.createCell((short) 4).setCellValue(account.getLevel()); 
	        
	        FileOutputStream out;// 新增輸出檔案流        
	        out = new FileOutputStream(fileName);
	        excelbook.write(out);// 把對應的Excel工作簿存碟
	        out.flush();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }
    /*public void insertPorderValue(Porder porder,String fileName,String sheetName)
    {
    	try {
			excelbook = new HSSFWorkbook(new FileInputStream(fileName));
			HSSFSheet sheet = excelbook.getSheet(sheetName);        //獲得指定的工作表
	        int count = sheet.getPhysicalNumberOfRows();  
	        
	        HSSFRow row = sheet.createRow((short) count); 
	        
	        row.createCell((short) 0).setCellValue(porder.getNo()); 
	        row.createCell((short) 1).setCellValue(porder.getId()); 
	        row.createCell((short) 2).setCellValue(porder.getNb()); 
	        row.createCell((short) 3).setCellValue(porder.getPc()); 
	        row.createCell((short) 4).setCellValue(porder.getMiniPc()); 
	        row.createCell((short) 5).setCellValue(porder.getTablet()); 
	        
	        FileOutputStream out;// 新增輸出檔案流        
	        out = new FileOutputStream(fileName);
	        excelbook.write(out);// 把對應的Excel工作簿存碟
	        out.flush();
		}catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
    }*/
}
