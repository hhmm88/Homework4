package util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import model.Account;
import model.Porder;
import model.Product;
import service.impl.AccountServiceImpl;
import service.impl.ProductServiceImpl;

public class ExportExcel {

	static HSSFSheet sheet;// = null;
    HSSFWorkbook excelbook=new HSSFWorkbook();
    
    public boolean createAccountAll(String fileName,String sheetName)
    {
    	boolean export = false;
    	try {
			FileOutputStream out = new FileOutputStream(fileName);
			
			 sheet = excelbook.createSheet(sheetName);
			 int count = 0;
			 HSSFRow row = sheet.createRow((short) count);
			 String[] titleName=new String[] {"編號","姓名","帳號","密碼","身分"};
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	          }
			 List<Account> accountList=(List<Account>)Tool.readFile("accountQuery.txt");
				//String show=member.getName()+",歡迎你";
			 
			// List<Account> accountList = new AccountServiceImpl().selectAll();
	            for(Account o:accountList )
	            {
	            	count++; 
			        
			        row = sheet.createRow((short) count); 
			        
			        row.createCell((short) 0).setCellValue(o.getId()); 
			        row.createCell((short) 1).setCellValue(o.getName()); 
			        row.createCell((short) 2).setCellValue(o.getUserName()); 
			        row.createCell((short) 3).setCellValue(o.getPassword()); 
			        row.createCell((short) 4).setCellValue(o.getLevel()); 
			        
	            }

		        excelbook.write(out);// 把對應的Excel工作簿存碟
		        out.flush();
		        out.close(); 
		        export=true;
			    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return export;
    }
    
    public boolean createProductAll(String fileName,String sheetName)
    {
    	boolean export = false;
    	try {
			FileOutputStream out = new FileOutputStream(fileName);
			
			 sheet = excelbook.createSheet(sheetName);
			 int count = 0;
			 HSSFRow row = sheet.createRow((short) count);
			 String[] titleName=new String[] {"序號", "商品編號", "商品名稱", "價格"};
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	          }
			
			 List<Product> productList=(List<Product>)Tool.readFile("productQuery.txt");

			 

	            for(Product p:productList )
	            {
	            	count++; 
			        
			        row = sheet.createRow((short) count); 
			        
			        row.createCell((short) 0).setCellValue(p.getId()); 
			        row.createCell((short) 1).setCellValue(p.getProductNo()); 
			        row.createCell((short) 2).setCellValue(p.getProductName()); 
			        row.createCell((short) 3).setCellValue(p.getPrice()); 
			        
	            }

		        excelbook.write(out);// 把對應的Excel工作簿存碟
		        out.flush();
		        out.close(); 
		        export=true;
			    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return export;
    }
    public boolean createPorderAll(String fileName,String sheetName) throws IOException
    {
    	boolean export = false;
    	try {
			FileOutputStream out = new FileOutputStream(fileName);
			sheet = excelbook.createSheet(sheetName);
			 int count = 0;
			 HSSFRow row = sheet.createRow((short) count);
			 String[] titleName=new String[] {"序號", "商品編號","商品名稱", "訂單數量","訂單金額"};
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	         }
			 List<Porder> porderList=(List<Porder>)Tool.readFile("porderDetailQuery.txt");

			 

	            for(Porder p:porderList )
	            {
	            	count++; 
			        
			        row = sheet.createRow((short) count); 
			        
			        row.createCell((short) 0).setCellValue(count); 
			        row.createCell((short) 1).setCellValue(p.getProductNo()); 
			        row.createCell((short) 2).setCellValue(new ProductServiceImpl().selectByPorductNo(p.getProductNo()).getProductName()); 
			        row.createCell((short) 3).setCellValue(p.getAmount()); 
			        row.createCell((short) 4).setCellValue(((int)new ProductServiceImpl().selectByPorductNo(p.getProductNo()).getPrice()*p.getAmount())); 
			        
	            }

		        excelbook.write(out);// 把對應的Excel工作簿存碟
		        out.flush();
		        out.close(); 
		        export=true;
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
    	return export;
    }
    /*
    public boolean createPorderAll(String fileName,String sheetName)
    {
    	boolean export = false;
    	try {
			FileOutputStream out = new FileOutputStream(fileName);
			
			 sheet = excelbook.createSheet(sheetName);
			 int count = 0;
			 HSSFRow row = sheet.createRow((short) count);
			 String[] titleName=new String[] {"編號","帳號","筆記電腦","桌上電腦","迷你電腦","平板電腦","交易金額"};
			 for(int i=0;i<titleName.length;i++)
	         {
	           	row.createCell((short) i).setCellValue(titleName[i]);
	          }
			 List<Porder> pordertList=(List<Porder>)Tool.readFile("poderQuery.txt");
				//String show=member.getName()+",歡迎你";
			 int sum=0;
			// List<Account> accountList = new AccountServiceImpl().selectAll();
	            for(Porder o:pordertList )
	            {
	            	count++; 
			        
			        row = sheet.createRow((short) count); 
			        sum=((o.getNb()*39000)+(o.getPc()*28000)+(o.getMiniPc()*16000)+(o.getTablet()*9000));
			        row.createCell((short) 0).setCellValue(o.getNo()); 
			        row.createCell((short) 1).setCellValue(o.getId()); 
			        row.createCell((short) 2).setCellValue(o.getNb()); 
			        row.createCell((short) 3).setCellValue(o.getPc()); 
			        row.createCell((short) 4).setCellValue(o.getMiniPc()); 
			        row.createCell((short) 5).setCellValue(o.getTablet()); 
			        row.createCell((short) 6).setCellValue(sum); 
			        
	            }

		        excelbook.write(out);// 把對應的Excel工作簿存碟
		        out.flush();
		        out.close(); 
		        export=true;
			    
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	return export;
    }
    */
    
}
