package util;

import java.util.List;

import model.Account;
import model.Porder;
import service.impl.AccountServiceImpl;
//import service.impl.PorderServiceImpl;

public class ShowString {

	public static String queryAccount(String userName)
	{
		String show="編號\t姓名    \t帳號    \t密碼    \t身分\n";
		show=show+"--------------------------------------------------------------------------------------------------";
		List<Account> list;
		if(userName==null)
			list = new AccountServiceImpl().selectAll();
		else
			list= new AccountServiceImpl().selectByUserNameList(userName);
		
		Tool.saveFile(list, "accountQuery.txt");
		for(Account a:list)
		{
			show=show+"\n"+a.getId()+"\t"+a.getName()+"    \t"+a.getUserName()+"    \t"+a.getPassword()+"    \t"+a.getLevel();
		}
		
		return show;
	}
/*	
	public static String queryPorder(int no,String id)
	{
		String show="編號\t收銀員帳號    \t筆記電腦    \t桌上電腦    \t迷你電腦    \t平板電腦    \t交易金額\n";
		show=show+"------------------------------------------------------------------------------------------------------------"+
		          "---------------------------------------";
		List<Porder> list;
		if(no==0 && id==null)
			list = new PorderServiceImpl().selectAll();
		else
			list= new PorderServiceImpl().selectByNoId(no,id);
		
		Tool.saveFile(list, "poderQuery.txt");
		for(Porder p:list)
		{
			show=show+"\n"+p.getNo()+"\t"+p.getId()+"    \t"+p.getNb()+"    \t"+p.getPc()
			         +"    \t"+p.getMiniPc()+"    \t"+p.getTablet()
			         +"    \t"+(((int)p.getNb()*39000)+((int)p.getPc()*28000)+((int)p.getMiniPc()*16000)+((int)p.getTablet()*9000));
		}
		
		
		return show;
	}
	*/
}
