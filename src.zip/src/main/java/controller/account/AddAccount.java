package controller.account;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.Login;
import model.Account;
import service.impl.AccountServiceImpl;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.Color;

public class AddAccount extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField id;
	private JTextField password;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddAccount frame = new AddAccount();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AddAccount() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 413, 335);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(-5, 9, 404, 46);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("會員註冊");
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 16));
		lblNewLabel.setBounds(156, 10, 70, 24);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 59, 398, 242);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("姓名");
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_1.setBounds(23, 21, 46, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("帳號");
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_2.setBounds(23, 58, 46, 15);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("密碼");
		lblNewLabel_3.setForeground(new Color(128, 128, 64));
		lblNewLabel_3.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_3.setBounds(23, 100, 46, 15);
		panel_1.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("身份");
		lblNewLabel_4.setForeground(new Color(128, 128, 64));
		lblNewLabel_4.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_4.setBounds(23, 145, 46, 15);
		panel_1.add(lblNewLabel_4);
		
		name = new JTextField();
		name.setForeground(new Color(128, 128, 64));
		name.setBounds(79, 18, 96, 21);
		panel_1.add(name);
		name.setColumns(10);
		
		id = new JTextField();
		id.setForeground(new Color(128, 128, 64));
		id.setBounds(79, 55, 96, 21);
		panel_1.add(id);
		id.setColumns(10);
		
		password = new JTextField();
		password.setForeground(new Color(128, 128, 64));
		password.setBounds(79, 97, 96, 21);
		panel_1.add(password);
		password.setColumns(10);
		
		JRadioButton level_2 = new JRadioButton("收銀員");
		level_2.setForeground(new Color(128, 128, 64));
		level_2.setFont(new Font("新細明體", Font.BOLD, 12));
		level_2.setSelected(true);
		buttonGroup.add(level_2);
		level_2.setBounds(75, 141, 69, 23);
		panel_1.add(level_2);
		
		JRadioButton level_1 = new JRadioButton("管理員");
		level_1.setForeground(new Color(128, 128, 64));
		level_1.setFont(new Font("新細明體", Font.BOLD, 12));
		buttonGroup.add(level_1);
		level_1.setBounds(151, 141, 74, 23);
		panel_1.add(level_1);
		
		JButton btnNewButton = new JButton("確認");
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Name = name.getText();
				String Id = id.getText();
				String Password = password.getText();
				String Level ="收銀員";
				if(level_1.isSelected()) Level="管理員";
				Account account = new Account(Name,Id,Password,Level);
				if(new AccountServiceImpl().addAccount(account))
				{
					JOptionPane.showMessageDialog(null, "註冊成功!");
					Login login = new Login();
					login.setVisible(true);
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "帳號重覆!");
				}
			}
		});
		btnNewButton.setBounds(102, 182, 87, 23);
		panel_1.add(btnNewButton);

	}

}
