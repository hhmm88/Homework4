package controller.account;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Account;
import service.impl.AccountServiceImpl;
import util.ExportExcel;
import util.ShowString;
import util.ShowTable;
import util.Tool;


import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JSpinner;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextArea;
import javax.swing.JButton;
import javax.swing.JCheckBox;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import controller.ManageUI;

//import controller.stock.SellStockUI.ButtonEditor;

public class AccountManagement extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField queryUserName;
	private JTextField addUserName;
	private JTextField addPassword;
	private JTextField addName;
	private JTextField updateUserName;
	private JTextField updatePassword;
	private JTextField delUserName;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AccountManagement frame = new AccountManagement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AccountManagement() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 601, 450);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 2, 586, 42);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("帳號管理");
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 16));
		lblNewLabel.setBounds(240, 10, 79, 22);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(-2, 45, 588, 221);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JButton btnNewButton_1 = new JButton("列印");
		btnNewButton_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					table.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
//				try {
//					showList.print();
//				} catch (PrinterException e1) {
//					// TODO Auto-generated catch block
//					e1.printStackTrace();
//				}
			}
		});
		btnNewButton_1.setBounds(453, 10, 64, 23);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("匯出");
		btnNewButton_2.setForeground(new Color(128, 128, 64));
		btnNewButton_2.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
	            JFileChooser jfileChooser = new JFileChooser();
	            if (jfileChooser.showSaveDialog(null)==JFileChooser.APPROVE_OPTION) {
		            File selectedFile=jfileChooser.getSelectedFile();
		            if (!selectedFile.getAbsolutePath().toLowerCase().endsWith(".xls")) {
		            	selectedFile = new File(selectedFile.getAbsolutePath() + ".xls");
		            }
		            ExportExcel create=new ExportExcel();
			            
		            if(create.createAccountAll(selectedFile.toString(), "Account"))
		            	JOptionPane.showMessageDialog(null, "匯出儲存成功!");
		            else
		            	JOptionPane.showMessageDialog(null, "匯出儲存失敗!");
		            	
	                
	                 
				}
				
			}
		});
		btnNewButton_2.setBounds(452, 43, 66, 23);
		panel_1.add(btnNewButton_2);
		
		
		

//		for(int i=0;i<list.size();i++)
//		{
//			for(int j=0;j<h.length;j++)
//			{
//				data[i][j]= 
//			}
//		}
//		for(Account[] o:data)
//		{
//			System.out.println(o);
//			for(Account p:o)
//			{
//				System.out.println(p.getId());
//				
//			}
//		}
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				
				int row = table.getSelectedRow();
				String value = table.getModel().getValueAt(row, 2).toString();
				//System.out.println(Constructs);
				updateUserName.setText(value);
				delUserName.setText(value);
				
			}
		});

		//String[] h = {"編號", "姓名", "帳號", "密碼", "身份","修改"};
		//List<Account> list = new AccountServiceImpl().selectAll();
		//Account[][] data = list.toArray(new Account[list.size()][5]);
		//String[][] data = new String[list.size()][6];
		/*String[][] data = new String[list.size()][5];
		int i=0;
		for(Account o:list)
		{
			data[i][0] = o.getNo()+"";
			data[i][1] = o.getName();
			data[i][2] = o.getId();
			data[i][3] = o.getPassword();
			data[i][4] = o.getLevel();
			//data[i][5] = "";
			i++;
		}*/
		String[][] data = ShowTable.queryAccount(null);
		table.setModel(new DefaultTableModel(data,new String[] {
				"編號", "姓名", "帳號", "密碼", "身份"
			}
			));
		/*table.setModel(new DefaultTableModel(
			new Object[][] {data
			},
			new String[] {
				"編號", "姓名", "帳號", "密碼", "身份"
			}
		));*/
		table.setBounds(10, 10, 433, 201);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(10, 10, 433, 201);
		panel_1.add(scrollPane);
		
		
		
		//panel_1.add(table);
		//table.getColumn("修改").setCellEditor(new DefaultCellEditor(new JCheckBox() ));

		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(128, 128, 64));
		panel_2.setBackground(new Color(199, 222, 182));
		panel_2.setBounds(0, 304, 584, 36);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("姓名");
		lblNewLabel_6.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_6.setForeground(new Color(128, 128, 64));
		lblNewLabel_6.setBounds(10, 10, 46, 15);
		panel_2.add(lblNewLabel_6);
		
		addName = new JTextField();
		addName.setBounds(43, 7, 96, 21);
		panel_2.add(addName);
		addName.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("帳號");
		lblNewLabel_4.setForeground(new Color(128, 128, 64));
		lblNewLabel_4.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_4.setBounds(145, 10, 46, 15);
		panel_2.add(lblNewLabel_4);
		
		addUserName = new JTextField();
		addUserName.setForeground(new Color(128, 128, 64));
		addUserName.setBounds(174, 7, 96, 21);
		panel_2.add(addUserName);
		addUserName.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("密碼");
		lblNewLabel_5.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_5.setForeground(new Color(128, 128, 64));
		lblNewLabel_5.setBounds(278, 10, 46, 15);
		panel_2.add(lblNewLabel_5);
		
		addPassword = new JTextField();
		addPassword.setBounds(308, 7, 96, 21);
		panel_2.add(addPassword);
		addPassword.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("身分");
		lblNewLabel_7.setForeground(new Color(128, 128, 64));
		lblNewLabel_7.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_7.setBounds(414, 10, 46, 15);
		panel_2.add(lblNewLabel_7);
		
		JComboBox<String> addLevel = new JComboBox();
		addLevel.setForeground(new Color(128, 128, 64));
		addLevel.setBounds(446, 6, 64, 23);
		panel_2.add(addLevel);
		
		JButton btnNewButton_3 = new JButton("新增");
		btnNewButton_3.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_3.setForeground(new Color(128, 128, 64));
		btnNewButton_3.setBounds(513, 7, 64, 23);
		panel_2.add(btnNewButton_3);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(199, 222, 182));
		panel_3.setBounds(0, 342, 585, 36);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_8 = new JLabel("帳號");
		lblNewLabel_8.setForeground(new Color(128, 128, 64));
		lblNewLabel_8.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_8.setBounds(9, 8, 46, 15);
		panel_3.add(lblNewLabel_8);
		
		updateUserName = new JTextField();
		updateUserName.setForeground(new Color(128, 128, 64));
		updateUserName.setBounds(40, 5, 96, 21);
		panel_3.add(updateUserName);
		updateUserName.setColumns(10);
		
		JLabel lblNewLabel_9 = new JLabel("密碼");
		lblNewLabel_9.setForeground(new Color(128, 128, 64));
		lblNewLabel_9.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_9.setBounds(144, 8, 46, 15);
		panel_3.add(lblNewLabel_9);
		
		updatePassword = new JTextField();
		updatePassword.setForeground(new Color(128, 128, 64));
		updatePassword.setBounds(175, 5, 96, 21);
		panel_3.add(updatePassword);
		updatePassword.setColumns(10);
		
		JButton btnNewButton_4 = new JButton("修改密碼");
		btnNewButton_4.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_4.setForeground(new Color(128, 128, 64));
		btnNewButton_4.setBounds(282, 4, 87, 23);
		panel_3.add(btnNewButton_4);
		
		JPanel panel_4 = new JPanel();
		panel_4.setBackground(new Color(199, 222, 182));
		panel_4.setBounds(0, 380, 476, 31);
		contentPane.add(panel_4);
		panel_4.setLayout(null);
		
		JLabel lblNewLabel_10 = new JLabel("帳號");
		lblNewLabel_10.setForeground(new Color(128, 128, 64));
		lblNewLabel_10.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_10.setBounds(10, 10, 30, 15);
		panel_4.add(lblNewLabel_10);
		
		delUserName = new JTextField();
		delUserName.setForeground(new Color(128, 128, 64));
		delUserName.setBounds(40, 7, 96, 21);
		panel_4.add(delUserName);
		delUserName.setColumns(10);
		
		JButton btnNewButton_5 = new JButton("刪除");
		btnNewButton_5.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_5.setForeground(new Color(128, 128, 64));
		btnNewButton_5.setBounds(156, 6, 87, 23);
		panel_4.add(btnNewButton_5);
		
		JPanel panel_5 = new JPanel();
		panel_5.setBackground(new Color(199, 222, 182));
		panel_5.setBounds(-1, 267, 587, 35);
		contentPane.add(panel_5);
		panel_5.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("帳號");
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_2.setBounds(10, 10, 46, 15);
		panel_5.add(lblNewLabel_2);
		
		queryUserName = new JTextField();
		queryUserName.setForeground(new Color(128, 128, 64));
		queryUserName.setBounds(44, 7, 96, 21);
		panel_5.add(queryUserName);
		queryUserName.setColumns(10);
		
		
		
		JButton btnNewButton = new JButton("查詢");
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setBounds(150, 6, 69, 23);
		panel_5.add(btnNewButton);
		
		JButton btnNewButton_6 = new JButton("回系統管理");
		btnNewButton_6.setBounds(481, 383, 96, 23);
		contentPane.add(btnNewButton_6);
		btnNewButton_6.setForeground(new Color(128, 128, 64));
		btnNewButton_6.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_6.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ManageUI ui = new ManageUI();
				ui.setVisible(true);
				dispose();
			}
		});
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String QueryId = queryUserName.getText();
				String show="";
				
				if(QueryId.isEmpty())
				{				
					//show = ShowString.queryAccount(null);
					String[][] data = ShowTable.queryAccount(null);
					table.setModel(new DefaultTableModel(data,new String[] {
							"編號", "姓名", "帳號", "密碼", "身份"
						}
						));
				}
				
				else 
				{
					//show = ShowString.queryAccount(QueryId);
					String[][] data = ShowTable.queryAccount(QueryId);
					table.setModel(new DefaultTableModel(data,new String[] {
							"編號", "姓名", "帳號", "密碼", "身份"
						}
						));

				}
			
				//showList.setText(show);
			}
		});
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String DelUserName = delUserName.getText();
				Account a = new Account();
				a.setUserName(DelUserName);
				boolean del = new AccountServiceImpl().deleteAccount(a);
				if(del)
				{
					JOptionPane.showMessageDialog(null, "刪除成功!");
					//showList.setText(ShowString.queryAccount(null));
					String[][] data = ShowTable.queryAccount(null);
					table.setModel(new DefaultTableModel(data,new String[] {
							"編號", "姓名", "帳號", "密碼", "身份"
						}
						));
					delUserName.setText("");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "無此帳號!");
				}
			}
		});
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String UpdateUserName = updateUserName.getText();
				String UpdatePassword = updatePassword.getText();

				Account a = new Account();
				a.setPassword(UpdatePassword);
				a.setUserName(UpdateUserName);
				boolean update =new AccountServiceImpl().updateAccount(a);
				if(update)
				{
					JOptionPane.showMessageDialog(null, "修改密碼成功!");
					//showList.setText(ShowString.queryAccount(null));
					String[][] data = ShowTable.queryAccount(null);
					table.setModel(new DefaultTableModel(data,new String[] {
							"編號", "姓名", "帳號", "密碼", "身份"
						}
						));
					updateUserName.setText("");
					updatePassword.setText("");
					
				}
				else
				{
					JOptionPane.showMessageDialog(null, "無此帳號!");
				}
				
			}
		});
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Name = addName.getText();
				String UserName = addUserName.getText();
				String Password = addPassword.getText();
				String Level =addLevel.getSelectedItem().toString();
				
				Account account = new Account(Name,UserName,Password,Level);
				if(new AccountServiceImpl().addAccount(account))
				{
					JOptionPane.showMessageDialog(null, "新增成功!");
					//showList.setText(ShowString.queryAccount(null));
					String[][] data = ShowTable.queryAccount(null);
					table.setModel(new DefaultTableModel(data,new String[] {
							"編號", "姓名", "帳號", "密碼", "身份"
						}
						));
					addName.setText("");
					addUserName.setText("");
					addPassword.setText("");

				}
				else
				{
					JOptionPane.showMessageDialog(null, "帳號重覆!");
				}
			}
		});
		addLevel.addItem("收銀員");
		addLevel.addItem("管理員");
		
		
		

	}
	public void receiveValue (String value)
	{
		//int row = table.getSelectedRow();
		//String value = table.getModel().getValueAt(row, 2).toString();
		AccountManagement a= new AccountManagement();
		System.out.println(value);
		a.queryUserName.setText("bbbbbbbbb");
	}
	public class Mydialog extends JDialog{                     //自訂義的Dialog中我只放入兩個東西 按鈕跟TextField想要放入更多東西可以自己設定
		 private JButton ok=new JButton("OK");
		 private JTextField TF = new JTextField("    ");
		 private JLabel ll = new JLabel("ID:");
		 
		 /*
		  * addName = new JTextField();
		addName.setBounds(43, 7, 96, 21);
		panel_2.add(addName);
		addName.setColumns(10);
		JLabel lblNewLabel = new JLabel("帳號管理");
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 16));
		lblNewLabel.setBounds(240, 10, 79, 22);
		panel.add(lblNewLabel);
		  * */
		 testclass tc;
		 public Mydialog()
		 {
		 JPanel JP=new JPanel();
		 add(JP);
		 JP.add(ok);
		 JP.add(TF);
		 JP.add(ll);
		 TF.setColumns(10);
		 ok.addActionListener(new ActionListener(){
		  public void actionPerformed(ActionEvent e){
		   setVisible(false);                                //點了這個按鈕之後就讓Dialog隱藏
		   tc=new testclass(TF.getText());
		   //queryId.setText(TF.getText());
		   dispose();                                          //讓Dialog 關閉
		   }
		  });
		 }
		 public testclass getValue()
		 {
		  setVisible(true);                     //呼叫此Function之後 讓Dialog顯示
		  return tc;
		 }
		}

		class testclass                                     //一個隨便定義的Class  表示 Dialog也可以回傳給Frame 自訂義Class
		{
		 String s;
		 public testclass(String ins)
		 {
		  s=ins;
		 }
		 public String getS()
		 {
		  return s;
		 }
		}
}
