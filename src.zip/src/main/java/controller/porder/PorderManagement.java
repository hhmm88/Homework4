package controller.porder;

import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.ManageUI;
import model.Porder;
import model.Product;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import util.ExportExcel;
import util.ShowTable;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.print.PrinterException;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import java.awt.Font;

public class PorderManagement extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PorderManagement frame = new PorderManagement();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PorderManagement() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 807, 324);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 793, 42);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("訂單管理");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(343, 10, 116, 22);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 45, 380, 240);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				int row = table.getSelectedRow();
				String productNo = table.getModel().getValueAt(row, 1).toString();
				System.out.println("productNo="+productNo);
				String[][] data1 = ShowTable.queryPorderDetail(productNo);
				table_1.setModel(new DefaultTableModel(data1,new String[] {
						"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
					}
				));
			}
		});
		table.setBounds(10, 304, 1, 1);
		JScrollPane scrollPane = new JScrollPane(table);	
		scrollPane.setBounds(10, 10, 360, 188);
		panel_1.add(scrollPane);
		String[][] data = ShowTable.queryPorder(null,null);
		table.setModel(new DefaultTableModel(data,new String[] {
				"序號", "訂單編號", "收銀員帳號", "收銀員姓名"
			}
		));
		
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(199, 222, 182));
		panel_2.setBounds(382, 45, 411, 240);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		table_1 = new JTable();
		table_1.setBounds(EXIT_ON_CLOSE, ABORT, WIDTH, HEIGHT);
		JScrollPane scrollPane_1 = new JScrollPane(table_1);
		scrollPane_1.setBounds(10, 10, 383, 175);
		panel_2.add(scrollPane_1);
		
		
		//scrollPane_1.setColumnHeaderView(table_1);
		//String[][] datat = ShowTable.queryPorderDetail("20250823001");
		String[][] datat = new String[1][3];
		table_1.setModel(new DefaultTableModel(datat,new String[] {
				"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
			}
		));
		
		JButton btnNewButton_4 = new JButton("列印");
		btnNewButton_4.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_4.setForeground(new Color(128, 128, 64));
		btnNewButton_4.setBounds(69, 195, 87, 23);
		panel_2.add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("匯出");
		btnNewButton_5.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_5.setForeground(new Color(128, 128, 64));
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				JFileChooser jfileChooser = new JFileChooser();
	            if (jfileChooser.showSaveDialog(null)==JFileChooser.APPROVE_OPTION) {
		            File selectedFile=jfileChooser.getSelectedFile();
		            if (!selectedFile.getAbsolutePath().toLowerCase().endsWith(".xls")) {
		            	selectedFile = new File(selectedFile.getAbsolutePath() + ".xls");
		            }
		            ExportExcel create=new ExportExcel();		           
		            try {
						if(create.createPorderAll(selectedFile.toString(), "Porder"))
							JOptionPane.showMessageDialog(null, "匯出儲存成功!");
						else
							JOptionPane.showMessageDialog(null, "匯出儲存失敗!");
					} catch (HeadlessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
		            	
	                
	                 
				}
			}
		});
		btnNewButton_5.setBounds(166, 195, 87, 23);
		panel_2.add(btnNewButton_5);
		
		JButton btnNewButton_5_1 = new JButton("回管理系統");
		btnNewButton_5_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ManageUI ui = new ManageUI();
				ui.setVisible(true);
				dispose();
			}
		});
		btnNewButton_5_1.setForeground(new Color(128, 128, 64));
		btnNewButton_5_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_5_1.setBounds(274, 195, 119, 23);
		panel_2.add(btnNewButton_5_1);
		btnNewButton_4.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					table_1.print();
				} catch (PrinterException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		
		
		JButton btnNewButton = new JButton("查詢");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				QueryPorder QP = new QueryPorder(PorderManagement.this);
				QP.setVisible(true);
			}
		});
		btnNewButton.setBounds(20, 208, 87, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("新增");
		btnNewButton_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AddPorder AP = new AddPorder(PorderManagement.this);
				AP.setVisible(true);
			}
		});
		btnNewButton_1.setBounds(141, 208, 87, 23);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("刪除");
		btnNewButton_3.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_3.setForeground(new Color(128, 128, 64));
		btnNewButton_3.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				String value = table.getModel().getValueAt(row, 1).toString();
				Porder porder = new Porder();
				//System.out.println(value);
				porder.setPorderNo(value);
				if(new PorderServiceImpl().deletePorder(porder))
				{
					JOptionPane.showMessageDialog(null, "刪除成功!");
					String[][] data = ShowTable.queryPorder(null, null);
					updateMainTextField(data);
					String[][]datat = new String[1][3];
					updateMainTextFieldDetail(datat);

				}
				else
				{
					JOptionPane.showMessageDialog(null, "刪除失敗!");
				}
			}
		});
		btnNewButton_3.setBounds(268, 208, 87, 23);
		panel_1.add(btnNewButton_3);

	}
	public void updateMainTextField(String[][] data) {
	       // this.textFieldMain.setText(text);
			
			//String[][] data = ShowTable.queryProduct(null);
			this.table.setModel(new DefaultTableModel(data,new String[] {
					"序號", "訂單編號", "收銀員帳號", "收銀員姓名"
				}
			));
	    }
	public void updateMainTextFieldDetail(String[][] data) {
	       // this.textFieldMain.setText(text);
			
			//String[][] data = ShowTable.queryProduct(null);
			this.table_1.setModel(new DefaultTableModel(data,new String[] {
					"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
				}
			));
	    }
}
