package controller.porder;

import java.awt.EventQueue;
import java.awt.Font;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Account;
import model.Porder;
import model.Product;
import service.impl.AccountServiceImpl;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import util.ShowTable;

import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AddPorder extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField addPorderNo;


	/**
	 * Create the frame.
	 */
	public AddPorder(PorderManagement pm) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 304, 489);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 290, 40);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("訂單新增");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 105, 290, 350);
		contentPane.add(panel_1);
		
		JLabel lblabc_1_1 = new JLabel("商品名稱");
		lblabc_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1.setBounds(10, 10, 58, 25);
		panel_1.add(lblabc_1_1);
		
		JLabel lblabc_1_1_1 = new JLabel("商品價格");
		lblabc_1_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1_1.setBounds(105, 10, 58, 25);
		panel_1.add(lblabc_1_1_1);
		
		JLabel lblabc_1_1_1_1 = new JLabel("訂單數量");
		lblabc_1_1_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1_1_1.setBounds(192, 9, 86, 25);
		panel_1.add(lblabc_1_1_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 45, 278, 265);
		panel_1.add(scrollPane);
		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(128, 128, 64));
		panel_2.setBackground(new Color(255, 255, 255));
		scrollPane.setViewportView(panel_2);
		panel_2.setLayout(null);
						
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(199, 222, 182));
		panel_3.setBounds(0, 43, 290, 63);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("收銀員帳號:");
		lblNewLabel_1.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(10, 38, 72, 15);
		panel_3.add(lblNewLabel_1);
		
		JComboBox addUserName = new JComboBox();
		addUserName.setForeground(new Color(128, 128, 64));
		addUserName.setBounds(92, 30, 100, 23);
		panel_3.add(addUserName);
		List<Account> list = new AccountServiceImpl().selectAll();						
		for(Account a:list)
		{
			if(a.getLevel().equals("收銀員"))
				addUserName.addItem(a.getUserName());
		}
		
		JLabel lblNewLabel_2 = new JLabel("訂單編號:");
		lblNewLabel_2.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setBounds(10, 10, 72, 15);
		panel_3.add(lblNewLabel_2);
				
		addPorderNo = new JTextField();
		addPorderNo.setForeground(new Color(128, 128, 64));
		addPorderNo.setEnabled(false);
		addPorderNo.setBounds(92, 7, 96, 21);
		panel_3.add(addPorderNo);
		addPorderNo.setColumns(10);
		PorderServiceImpl psi = new PorderServiceImpl();
		addPorderNo.setText(psi.getPorderNo());
		
		ProductServiceImpl pdi = new ProductServiceImpl();
		List<Product> products = pdi.selectAll();
		List<JTextField> quantityField = new ArrayList<>();
		List<Porder> porderList = new ArrayList<>();
		int y=14;
		for(Product o:products)
		{
			JLabel nameLabel = new JLabel(o.getProductName());
			nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			nameLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
			nameLabel.setBounds(14, y, 58, 25);
			panel_2.add(nameLabel);
			
			JLabel priceLabel = new JLabel(o.getPrice()+"元");
			priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			priceLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
			priceLabel.setBounds(105, y, 58, 25);
			panel_2.add(priceLabel);
			
			JTextField qtyField = new JTextField();
			quantityField.add(qtyField);
			qtyField.setText("0");
			qtyField.setHorizontalAlignment(SwingConstants.CENTER);
			qtyField.setColumns(10);
			qtyField.setBounds(178, y, 86, 25);
			panel_2.add(qtyField);
			
			y+=30;			
		}
		
		
		
		JButton btnNewButton = new JButton("確定");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String AddPorderNo = addPorderNo.getText();
				String AddUserName = addUserName.getSelectedItem().toString();
				 Porder p = new Porder();
				 Map<String, Integer> PA = new HashMap<>();
				for (int i = 0; i < products.size(); i++) 
				{
		            String text = quantityField.get(i).getText();
		            if (!text.isEmpty()) 
		            {
		               int qty = Integer.parseInt(text);
		                 if (qty > 0) 
		                 {
		                    Product product = products.get(i);		                    
		                    PA.put(product.getProductNo(), qty);
		        
		                } 
		                 
		            }
		        }
				p.setPorderNo(AddPorderNo);
				p.setUserName(AddUserName);
				p.setProductAmount(PA);
				if(psi.insertPorder(p))
				{
					JOptionPane.showMessageDialog(null, "新增成功!");
					String[][] data = ShowTable.queryPorder(null,null);
					pm.updateMainTextField(data);
					String[][]datat = new String[1][3];
					pm.updateMainTextFieldDetail(datat);
					dispose();
				}
			}
		});
		btnNewButton.setBounds(98, 317, 87, 23);
		panel_1.add(btnNewButton);
		
	}

}
