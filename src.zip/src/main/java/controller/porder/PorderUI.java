package controller.porder;

import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import controller.Login;
import model.Account;
import model.Porder;
import model.Product;
import service.impl.AccountServiceImpl;
import service.impl.PorderServiceImpl;
import service.impl.ProductServiceImpl;
import util.ShowTable;
import util.Tool;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;

public class PorderUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable table;
	private JTable table_1;
	private JTextField addPorderNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PorderUI frame = new PorderUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PorderUI() {
		Account account = (Account)Tool.readFile("account.txt");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 771, 582);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setForeground(new Color(128, 128, 64));
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 758, 41);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("資訊收銀系統");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(296, 10, 139, 21);
		panel.add(lblNewLabel);

		JPanel panel_1 = new JPanel();
		panel_1.setLayout(null);
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 226, 758, 317);
		contentPane.add(panel_1);
		
		JLabel lblabc_1_1 = new JLabel("商品名稱");
		lblabc_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1.setBounds(10, 10, 58, 25);
		panel_1.add(lblabc_1_1);
		
		JLabel lblabc_1_1_1 = new JLabel("商品價格");
		lblabc_1_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1_1.setBounds(105, 10, 58, 25);
		panel_1.add(lblabc_1_1_1);
		
		JLabel lblabc_1_1_1_1 = new JLabel("訂單數量");
		lblabc_1_1_1_1.setForeground(new Color(128, 128, 64));
		lblabc_1_1_1_1.setFont(new Font("微軟正黑體", Font.BOLD, 14));
		lblabc_1_1_1_1.setBounds(192, 9, 86, 25);
		panel_1.add(lblabc_1_1_1_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(5, 45, 278, 265);
		panel_1.add(scrollPane);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(255, 255, 255));
		scrollPane.setViewportView(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("收銀員:");
		lblNewLabel_1.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(311, 18, 58, 17);
		panel_1.add(lblNewLabel_1);
		
		JLabel accountName = new JLabel("");
		accountName.setFont(new Font("新細明體", Font.BOLD, 12));
		accountName.setForeground(new Color(128, 128, 64));
		accountName.setBounds(364, 18, 106, 17);
		panel_1.add(accountName);
		accountName.setText(account.getName());
		
		JLabel lblNewLabel_2 = new JLabel("時間:");
		lblNewLabel_2.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setBounds(533, 18, 46, 17);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_3.setForeground(new Color(128, 128, 64));
		//lblNewLabel_3.setBounds(570, 18, 191, 17);
		panel_1.add(lblNewLabel_3);
		Tool.updateDateTime(lblNewLabel_3);	
		Timer timer = new Timer(1000, e -> Tool.updateDateTime(lblNewLabel_3));
		timer.start();
		lblNewLabel_3.setBounds(570, 18, 179, 17);
		
		JLabel lblNewLabel_4 = new JLabel("訂單編號:");
		lblNewLabel_4.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_4.setForeground(new Color(128, 128, 64));
		lblNewLabel_4.setBounds(293, 45, 65, 17);
		panel_1.add(lblNewLabel_4);
		
		addPorderNo = new JTextField();
		addPorderNo.setForeground(new Color(128, 128, 64));
		addPorderNo.setEnabled(false);
		addPorderNo.setBounds(355, 43, 96, 21);
		panel_1.add(addPorderNo);
		addPorderNo.setColumns(10);
		addPorderNo.setText(new PorderServiceImpl().getPorderNo());
		
		
		
		
		JPanel panel_3 = new JPanel();
		panel_3.setBackground(new Color(199, 222, 182));
		panel_3.setBounds(0, 44, 758, 180);
		contentPane.add(panel_3);
		panel_3.setLayout(null);
		JScrollPane scrollPane_2 = new JScrollPane(table);
		scrollPane_2.setBounds(10, 10, 344, 142);
		panel_3.add(scrollPane_2);
	
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				int row = table.getSelectedRow();
				String productNo = table.getModel().getValueAt(row, 1).toString();
				String[][] data1 = ShowTable.queryPorderDetail(productNo);
				table_1.setModel(new DefaultTableModel(data1,new String[] {
						"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
					}
				));
			}
		});
		scrollPane_2.setViewportView(table);
		String[][] data = ShowTable.queryPorder(account.getUserName(),null);
		table.setModel(new DefaultTableModel(data,new String[] {
				"序號", "訂單編號", "收銀員帳號", "收銀員姓名"
			}
		));
		
		
		JScrollPane scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(364, 10, 386, 142);
		panel_3.add(scrollPane_1);
		
		table_1 = new JTable();
		scrollPane_1.setViewportView(table_1);
		String[][] datat = new String[1][5];
		table_1.setModel(new DefaultTableModel(datat,new String[] {
				"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
			}
		));
						
		
		
		ProductServiceImpl pdi = new ProductServiceImpl();
		List<Product> products = pdi.selectAll();
		List<JTextField> quantityField = new ArrayList<>();
		List<Porder> porderList = new ArrayList<>();
		int y=14;
		for(Product o:products)
		{
			JLabel nameLabel = new JLabel(o.getProductName());
			nameLabel.setHorizontalAlignment(SwingConstants.CENTER);
			nameLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
			nameLabel.setBounds(14, y, 58, 25);
			panel_2.add(nameLabel);
			
			JLabel priceLabel = new JLabel(o.getPrice()+"元");
			priceLabel.setHorizontalAlignment(SwingConstants.CENTER);
			priceLabel.setFont(new Font("微軟正黑體", Font.PLAIN, 14));
			priceLabel.setBounds(105, y, 58, 25);
			panel_2.add(priceLabel);
			
			JTextField qtyField = new JTextField();
			quantityField.add(qtyField);
			qtyField.setText("0");
			qtyField.setHorizontalAlignment(SwingConstants.CENTER);
			qtyField.setColumns(10);
			qtyField.setBounds(178, y, 86, 25);
			panel_2.add(qtyField);
			
			y+=30;			
		}
		
		
		JButton btnNewButton = new JButton("新增");
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String AddPorderNo = addPorderNo.getText();
				String AddUserName = account.getUserName();
				 Porder p = new Porder();
				 Map<String, Integer> PA = new HashMap<>();
				for (int i = 0; i < products.size(); i++) 
				{
		            String text = quantityField.get(i).getText();
		            if (!text.isEmpty()) 
		            {
		               int qty = Integer.parseInt(text);
		                 if (qty > 0) 
		                 {
		                    Product product = products.get(i);		                    
		                    PA.put(product.getProductNo(), qty);
		        
		                } 
		                 
		            }
		        }
				p.setPorderNo(AddPorderNo);
				p.setUserName(AddUserName);
				p.setProductAmount(PA);
				if(new PorderServiceImpl().insertPorder(p))
				{
					JOptionPane.showMessageDialog(null, "新增成功!");
					String[][] data = ShowTable.queryPorder(account.getUserName(),null);
					updateMainTextField(data);
					String[][]datat = new String[1][3];
					updateMainTextFieldDetail(datat);
					
				}
				
			}
		});
		btnNewButton.setBounds(364, 97, 87, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("刪除");
		btnNewButton_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				String value = table.getModel().getValueAt(row, 1).toString();
				Porder porder = new Porder();
				porder.setPorderNo(value);
				if(new PorderServiceImpl().deletePorder(porder))
				{
					JOptionPane.showMessageDialog(null, "刪除成功!");
					String[][] data = ShowTable.queryPorder(account.getUserName(), null);
					updateMainTextField(data);
					String[][]datat = new String[1][3];
					updateMainTextFieldDetail(datat);

				}
				else
				{
					JOptionPane.showMessageDialog(null, "刪除失敗!");
				}
			}
		});
		btnNewButton_1.setBounds(364, 171, 87, 23);
		panel_1.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("登出");
		btnNewButton_1_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login ui = new Login();
				ui.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1_1.setBounds(364, 249, 87, 23);
		panel_1.add(btnNewButton_1_1);
		//contentPane.add(lblNewLabel_3);
		

	}
	public void updateMainTextField(String[][] data) {
	       // this.textFieldMain.setText(text);
			
			//String[][] data = ShowTable.queryProduct(null);
			this.table.setModel(new DefaultTableModel(data,new String[] {
					"序號", "訂單編號", "收銀員帳號", "收銀員姓名"
				}
			));
	    }
	public void updateMainTextFieldDetail(String[][] data) {
	       // this.textFieldMain.setText(text);
			
			//String[][] data = ShowTable.queryProduct(null);
			this.table_1.setModel(new DefaultTableModel(data,new String[] {
					"序號", "商品編號","商品名稱", "訂單數量","訂單金額"
				}
			));
	    }

}
