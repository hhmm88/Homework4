package controller.porder;

import java.awt.EventQueue;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import model.Account;
import service.impl.AccountServiceImpl;
import util.ShowTable;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class QueryPorder extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField queryPorderNo;
	private JTextField queryUserName;


	/**
	 * Create the frame.
	 */
	public QueryPorder(PorderManagement pm) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 432, 173);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 424, 52);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("訂單查詢");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(168, 10, 80, 32);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 56, 424, 81);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("收銀員帳號:");
		lblNewLabel_1.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(10, 10, 87, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("訂單編號:");
		lblNewLabel_2.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setBounds(204, 10, 69, 15);
		panel_1.add(lblNewLabel_2);
		
		queryPorderNo = new JTextField();
		queryPorderNo.setFont(new Font("新細明體", Font.BOLD, 12));
		queryPorderNo.setForeground(new Color(128, 128, 64));
		queryPorderNo.setBounds(270, 7, 96, 21);
		panel_1.add(queryPorderNo);
		queryPorderNo.setColumns(10);
		
		//JComboBox queryUserName = new JComboBox();
		//queryUserName.setBounds(57, 6, 104, 23);
		//panel_1.add(queryUserName);
		
		JButton btnNewButton = new JButton("確定");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				//String QueryUserName = queryUserName.getSelectedItem().toString();
				
				String QueryUserName = queryUserName.getText();
				String QueryPorderNo = queryPorderNo.getText();
				String[][] data,datat;
				if(QueryUserName.isEmpty() && QueryPorderNo.isEmpty())
					 data = ShowTable.queryPorder(null, null);
				else if(QueryUserName.isEmpty())
					 data = ShowTable.queryPorder(null, QueryPorderNo);
				else if(QueryPorderNo.isEmpty())
					 data = ShowTable.queryPorder(QueryUserName, null);
				else
					 data = ShowTable.queryPorder(QueryUserName, QueryPorderNo);

				
				 pm.updateMainTextField(data);
				 datat = new String[1][3];
				 pm.updateMainTextFieldDetail(datat);
				dispose();
			}
		});
		btnNewButton.setBounds(153, 35, 87, 23);
		panel_1.add(btnNewButton);
		
		queryUserName = new JTextField();
		queryUserName.setFont(new Font("新細明體", Font.BOLD, 12));
		queryUserName.setForeground(new Color(128, 128, 64));
		queryUserName.setBounds(79, 7, 96, 21);
		panel_1.add(queryUserName);
		queryUserName.setColumns(10);
		/*List<Account> list = new AccountServiceImpl().selectAll();						
		for(Account a:list)
		{
			if(a.getLevel().equals("收銀員"))
			   queryUserName.addItem(a.getUserName());
		}*/

	}
}
