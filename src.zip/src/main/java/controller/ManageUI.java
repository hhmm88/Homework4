package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

import controller.account.AccountManagement;
import controller.porder.PorderManagement;
import controller.product.ProductManagement;
import model.Account;
import util.Tool;

import javax.swing.JScrollPane;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Font;

public class ManageUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ManageUI frame = new ManageUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ManageUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 493, 246);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 10, 483, 47);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("資訊收銀系統管理");
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 16));
		lblNewLabel.setBounds(167, 9, 142, 24);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 60, 483, 42);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("管理員:");
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_1.setBounds(10, 10, 54, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setFont(new Font("新細明體", Font.BOLD, 13));
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setBounds(64, 10, 46, 15);
		panel_1.add(lblNewLabel_2);
		Account account = (Account)Tool.readFile("account.txt");
		lblNewLabel_2.setText(account.getName());
		
		JLabel lblNewLabel_3 = new JLabel("時間:");
		lblNewLabel_3.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_3.setForeground(new Color(128, 128, 64));
		lblNewLabel_3.setBounds(293, 10, 46, 15);
		panel_1.add(lblNewLabel_3);
		
		
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(199, 222, 182));
		panel_2.setBounds(0, 106, 483, 101);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setForeground(new Color(128, 128, 64));
		lblNewLabel_4.setBounds(333, 10, 140, 15);
		panel_1.add(lblNewLabel_4);
		
		//JLabel dateTimlblNewLabel_4eLabel = new JLabel("2025-01-16 22:38:34");
		Tool.updateDateTime(lblNewLabel_4);	
		Timer timer = new Timer(1000, e -> Tool.updateDateTime(lblNewLabel_4));
		timer.start();
		
		JButton btnNewButton = new JButton("帳號管理");
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AccountManagement am = new AccountManagement();
				am.setVisible(true);
				dispose();
			}
		});
		btnNewButton.setBounds(24, 39, 87, 23);
		panel_2.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("訂單管理");
		btnNewButton_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				PorderManagement pm = new PorderManagement();
				pm.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(133, 39, 87, 23);
		panel_2.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("登出");
		btnNewButton_2.setForeground(new Color(128, 128, 64));
		btnNewButton_2.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				Login ui = new Login();
				ui.setVisible(true);
				dispose();
			}
		});
		btnNewButton_2.setBounds(357, 39, 87, 23);
		panel_2.add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("商品管理");
		btnNewButton_2_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				ProductManagement pm = new ProductManagement();
				pm.setVisible(true);
				dispose();
				
			}
		});
		btnNewButton_2_1.setForeground(new Color(128, 128, 64));
		btnNewButton_2_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_2_1.setBounds(249, 39, 87, 23);
		panel_2.add(btnNewButton_2_1);

	}
}
