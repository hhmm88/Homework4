package controller.product;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import model.Product;
import service.impl.ProductServiceImpl;
import util.ShowTable;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class AddProduct extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField name;
	private JTextField price;

	

	/**
	 * Create the frame.
	 */
	public AddProduct(ProductManagement pm) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 437, 171);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 424, 37);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("商品新增");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(171, 10, 70, 23);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 40, 424, 91);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("商品名稱:");
		lblNewLabel_1.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(21, 10, 63, 22);
		panel_1.add(lblNewLabel_1);
		
		name = new JTextField();
		name.setFont(new Font("新細明體", Font.BOLD, 12));
		name.setForeground(new Color(128, 128, 64));
		name.setBounds(85, 11, 96, 21);
		panel_1.add(name);
		name.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("商品價格:");
		lblNewLabel_2.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setBounds(21, 41, 63, 15);
		panel_1.add(lblNewLabel_2);
		
		price = new JTextField();
		price.setFont(new Font("新細明體", Font.BOLD, 12));
		price.setForeground(new Color(128, 128, 64));
		price.setBounds(85, 38, 96, 21);
		panel_1.add(price);
		price.setColumns(10);
		
		JButton btnNewButton = new JButton("確定");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String No = new ProductServiceImpl().getProductNo();
				String Name = name.getText();
				int Price = Integer.parseInt(price.getText());
				Product product = new Product(No,Name,Price);
				if(new ProductServiceImpl().insertProduct(product))
				{
					JOptionPane.showMessageDialog(null, "新增成功!");
					String[][] data = ShowTable.queryProduct(null);
					pm.updateMainTextField(data);
					dispose();
				}
				else
				{
					JOptionPane.showMessageDialog(null, "新增失敗!");
					dispose();
				}
			}
		});
		btnNewButton.setBounds(209, 37, 87, 23);
		panel_1.add(btnNewButton);

	}

}
