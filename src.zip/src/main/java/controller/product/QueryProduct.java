package controller.product;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import util.ShowTable;

import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;

public class QueryProduct extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;

	

	/**
	 * Create the frame.
	 */
	public QueryProduct(ProductManagement pm) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 343, 138);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);//Absolute layout
		contentPane.setLayout(null);//Absolute layout
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 330, 50);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("商品查詢");
		lblNewLabel.setFont(new Font("標楷體", Font.BOLD, 15));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(103, 10, 71, 30);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 54, 330, 50);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("商品編號:");
		lblNewLabel_1.setFont(new Font("新細明體", Font.BOLD, 12));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(10, 10, 61, 15);
		panel_1.add(lblNewLabel_1);
		
		textField = new JTextField();
		textField.setFont(new Font("新細明體", Font.BOLD, 12));
		textField.setForeground(new Color(128, 128, 64));
		textField.setBounds(81, 7, 96, 21);
		panel_1.add(textField);
		textField.setColumns(10);
		
		JButton btnNewButton = new JButton("確定");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String PN=textField.getText();
				if(PN.isEmpty()) PN=null;
				String[][] data = ShowTable.queryProduct(PN);
				pm.updateMainTextField(data);
				dispose();
			}
		});
		btnNewButton.setBounds(187, 6, 87, 23);
		panel_1.add(btnNewButton);

	}
}
