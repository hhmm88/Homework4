package controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controller.account.AddAccount;
import controller.porder.PorderUI;
import model.Account;
import service.impl.AccountServiceImpl;
import util.Tool;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Color;
import java.awt.Font;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField id;
	private JTextField password;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 407, 271);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(199, 222, 182));
		panel.setBounds(0, 0, 390, 47);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("資訊收銀系統");
		lblNewLabel.setFont(new Font("新細明體", Font.BOLD, 16));
		lblNewLabel.setForeground(new Color(128, 128, 64));
		lblNewLabel.setBounds(131, 14, 122, 27);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(128, 128, 64));
		panel_1.setBackground(new Color(199, 222, 182));
		panel_1.setBounds(0, 50, 390, 188);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("帳號");
		lblNewLabel_1.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_1.setForeground(new Color(128, 128, 64));
		lblNewLabel_1.setBounds(84, 25, 46, 15);
		panel_1.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("密碼");
		lblNewLabel_2.setForeground(new Color(128, 128, 64));
		lblNewLabel_2.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_2.setBounds(84, 62, 46, 15);
		panel_1.add(lblNewLabel_2);
		
		id = new JTextField();
		id.setForeground(new Color(128, 128, 64));
		id.setBounds(140, 22, 96, 21);
		panel_1.add(id);
		id.setColumns(10);
		
		password = new JTextField();
		password.setForeground(new Color(128, 128, 64));
		password.setBounds(140, 59, 96, 21);
		panel_1.add(password);
		password.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("身份");
		lblNewLabel_3.setFont(new Font("標楷體", Font.BOLD, 13));
		lblNewLabel_3.setForeground(new Color(128, 128, 64));
		lblNewLabel_3.setBounds(84, 97, 46, 15);
		panel_1.add(lblNewLabel_3);
		
		JRadioButton level_2 = new JRadioButton("收銀員");
		level_2.setForeground(new Color(128, 128, 64));
		level_2.setFont(new Font("標楷體", Font.BOLD, 12));
		level_2.setSelected(true);
		buttonGroup.add(level_2);
		level_2.setBounds(140, 93, 66, 23);
		panel_1.add(level_2);
		
		JRadioButton level_1 = new JRadioButton("管理員");
		level_1.setFont(new Font("標楷體", Font.BOLD, 12));
		level_1.setForeground(new Color(128, 128, 64));
		buttonGroup.add(level_1);
		level_1.setBounds(216, 93, 66, 23);
		panel_1.add(level_1);
		
		
		JButton btnNewButton = new JButton("登入");
		btnNewButton.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton.setForeground(new Color(128, 128, 64));
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String Id = id.getText();
				String Password = password.getText();
				Account account = new AccountServiceImpl().login(Id, Password);
				if(account!=null) {
					Tool.saveFile(account, "account.txt");

					String level =account.getLevel();
					
					if((level.equals("管理員") && level_1.isSelected()) || (level.equals("收銀員") && level_2.isSelected()))
					{	
						if(level.equals("管理員"))
						{
							ManageUI manageui = new ManageUI();
							manageui.setVisible(true);
							dispose();
					
						
						}else
						{
							PorderUI porderui = new PorderUI();
							porderui.setVisible(true);
							dispose();
						}
					}
					else
					{
						JOptionPane.showMessageDialog(null, "身分錯誤!");
					}
				}
				else
				{
					JOptionPane.showMessageDialog(null, "帳號密碼錯誤!");
				}
			}
		});
		btnNewButton.setBounds(86, 138, 87, 23);
		panel_1.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("註冊");
		btnNewButton_1.setForeground(new Color(128, 128, 64));
		btnNewButton_1.setFont(new Font("新細明體", Font.BOLD, 12));
		btnNewButton_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				AddAccount addAccount = new AddAccount();
				addAccount.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(216, 138, 87, 23);
		panel_1.add(btnNewButton_1);

	}
}
