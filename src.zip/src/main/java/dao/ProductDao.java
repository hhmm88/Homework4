package dao;

import java.util.List;

import model.Product;

public interface ProductDao {
		
	 		void insert(Product product);
	 		
	 		void delete(Product product);
	 		
	 		void update(Product product);
	 		
	 		List<Product> select();
	 		List<Product> selectPorductNoList(String productNo);
	 		Product selectPorductNo(String productNo);
	 		String getNo();
	 		
}
