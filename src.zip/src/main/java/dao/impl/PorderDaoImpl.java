package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dao.PorderDao;
import model.Porder;
import model.Product;
import util.DbConnection;

public class PorderDaoImpl implements PorderDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	  /*List<Porder> a=new PorderDaoImpl().selectDetailAll("20250823001");
	  for(Porder o:a)
	  {
		  System.out.println(o.getProductNo());
		  System.out.println(o.getAmount());
	  }*/
		//System.out.println(new PorderDaoImpl().getNo());
	}

	private static Connection conn = DbConnection.getDbConn();
	@Override
	public void insert(Porder porder) {
		
		String sql="insert into porder (porderno,userName) values(?,?)";		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			
			ps.setString(1, porder.getPorderNo());
			ps.setString(2, porder.getUserName());
			ps.executeUpdate();
			
			
			//ps = conn.prepareStatement(sql2);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String sql1="insert into porder_detail (porderno,productNo,amount) values(?,?,?)";
		porder.getProductAmount().forEach((productNo, amount) -> {
			try {
				PreparedStatement ps = conn.prepareStatement(sql1);
				ps.setString(1, porder.getPorderNo());
				ps.setString(2, productNo);
				ps.setInt(3, amount);
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	
	}

	@Override
	public void update(Porder porder) {
		String sql="update porder set username=? where porderno=?";		
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder.getUserName());
			ps.setString(2, porder.getPorderNo());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql1="delete from porder_detail where porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql1);
			ps.setString(1, porder.getPorderNo());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql2="insert into porder_detail (porderno,productNo,amount) values(?,?,?)";
		porder.getProductAmount().forEach((productNo, amount) -> {
			try {
				if (amount > 0) {
					PreparedStatement ps = conn.prepareStatement(sql2);
					ps.setString(1, porder.getPorderNo());
					ps.setString(2, productNo);
					ps.setInt(3, amount);
					ps.executeUpdate();
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});
	}

	@Override
	public void delete(Porder porder) {
		String sql="delete from porder where porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porder.getPorderNo());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String sql1="delete from porder_detail where porderno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql1);
			ps.setString(1, porder.getPorderNo());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public List<Porder> selectAll() {
		String sql="select * from porder";
		List<Porder> porderList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderNo(rs.getString("porderNo"));
				porder.setUserName(rs.getString("userName"));

				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porderList;
	}

	@Override
	public List<Porder> selectNo(String userName, String porderNo) {
		String sql="select * from porder where username=? or porderno=?";
		List<Porder> porderList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, porderNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setId(rs.getInt("id"));
				porder.setPorderNo(rs.getString("porderNo"));
				porder.setUserName(rs.getString("userName"));
				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porderList;
	}



	@Override
	public List<Porder> selectDetailAll(String porderNo) {
		String sql="select * from porder_detail where porderNo=? ";
		List<Porder> porderList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, porderNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setProductNo(rs.getString("productNo"));
				porder.setAmount(rs.getInt("amount"));

				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porderList;
	}

	@Override
	public List<Porder> selectUserName(String userName) {
		String sql="select * from porder where username=?";
		List<Porder> porderList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Porder porder = new Porder();
				porder.setUserName(rs.getString("userName"));
				porderList.add(porder);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return porderList;
	}

	@Override
	public Map<String, Integer> selectDetail(String porderNo) {
		Porder porder = new Porder();
		Map<String, Integer> porderDetail = porder.getProductAmount();
		
		 ProductDaoImpl pdi = new ProductDaoImpl();
		 
		List<Product> productList =  pdi.select();
		for(Product o:productList)
		{
			porderDetail.put(o.getProductNo(), 0);
		}
		
		String sql="select * from porder_detail where porderno=?";
		
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, porderNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				porderDetail.put(rs.getString("productNo"), rs.getInt("amount"));				
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

		
		return porderDetail;
	}

	@Override
	public String getNo() {
		String porderNo=null;
		LocalDateTime dateTime = LocalDateTime.now();
		LocalDate date = dateTime.toLocalDate();
		String pdate = dateTime.format(DateTimeFormatter.ofPattern("yyyyMMdd"));
		String sql ="select CONCAT('"+pdate+"',lpad(max(right(porderno,3))+1,3,'0')) as no from porder where porderno like '"+pdate+"%'";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();			
			if(rs.next())
			{
				porderNo = rs.getString("no");
				if(porderNo == null) porderNo = pdate+"001";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return porderNo;
	}


	
}
