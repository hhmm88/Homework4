package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.AccountDao;
import model.Account;
import util.DbConnection;

public class AccountDaoImpl implements AccountDao  {

	public static void main(String[] args) {
		List<Account> l=new AccountDaoImpl().selectUserNameList("wang");
		for(Account o:l)
		{
			System.out.println(o.getUserName()+"\t"+o.getName()+"\tlevel:"+o.getLevel());
			
		}

	}

	private static Connection conn = DbConnection.getDbConn();

	@Override
	public void add(Account account) {

		String sql = "insert into account (name,username,password,level) values(?,?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, account.getName());
			ps.setString(2, account.getUserName());
			ps.setString(3, account.getPassword());
			ps.setString(4, account.getLevel());
			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	@Override
	public List<Account> select() {
		String sql="select * from account";
		List<Account> l=new ArrayList();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Account a=new Account();
				a.setId(rs.getInt("id"));
				a.setUserName(rs.getString("userName"));
				a.setName(rs.getString("name"));
				a.setPassword(rs.getString("password"));
				a.setLevel(rs.getString("level"));				
				
				l.add(a);
			
			
			}
			
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return l;
	}

	@Override
	public Account selectUserName(String userName) {
		Account account=null;
		String sql="select * from account where username=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				account = new Account();
				account.setId(rs.getInt("id"));
				account.setUserName(rs.getString("userName"));
				account.setName(rs.getString("name"));
				account.setPassword(rs.getString("Password"));
				account.setLevel(rs.getString("level"));
				
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return account;
	}

	@Override
	public void update(Account account) {

		String Sql="update account set password=? where username=?";
		try {
			PreparedStatement ps=conn.prepareStatement(Sql);
			ps.setString(1, account.getPassword());
			ps.setString(2, account.getUserName());
			
			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void delete(Account account) {

		String sql="delete from account where username=?";
		
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, account.getUserName());
			
			ps.executeUpdate();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public Account selectUserNamePassword(String userName, String password) {
		Account account=null;
		String sql="select * from account where username=? and password=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			
			if(rs.next())
			{
				account = new Account();
				account.setId(rs.getInt("id"));
				account.setUserName(rs.getString("userName"));
				account.setName(rs.getString("name"));
				account.setPassword(rs.getString("Password"));
				account.setLevel(rs.getString("level"));
				
				
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return account;
	}

	@Override
	public List<Account> selectUserNameList(String userName) {
		Account account=null;
		String sql="select * from account where username=?";
		List<Account> l=new ArrayList();
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				account = new Account();
				account.setId(rs.getInt("id"));
				account.setUserName(rs.getString("userName"));
				account.setName(rs.getString("name"));
				account.setPassword(rs.getString("Password"));
				account.setLevel(rs.getString("level"));
				
				
				l.add(account);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return l;
	}

	@Override
	public String selectName(String userName) {
		String name=null;
		String sql="select name from account where username=?";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ps.setString(1, userName);
			ResultSet rs=ps.executeQuery();			
			if(rs.next())
				name = rs.getString("name");							
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return name;
	}

	

	

	
}
