package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.ProductDao;
import model.Product;
import util.DbConnection;

public class ProductDaoImpl implements ProductDao {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product a = new Product();
		a.setProductName("p");
		a.setPrice(11111);
		a.setProductNo("p002");
	    new ProductDaoImpl().update(a);

	}

	private static Connection conn = DbConnection.getDbConn();
	@Override
	public void insert(Product product) {
		String sql="insert into product (productno,productname,price) values(?,?,?)";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, product.getProductNo());
			ps.setString(2, product.getProductName());
			ps.setInt(3, product.getPrice());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void delete(Product product) {
		String sql="delete from product where productno=?";
		System.out.println(sql);
		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, product.getProductNo());
			
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void update(Product product) {
		String sql="update product set productname=?,price=? where productno=?";
		try {
			PreparedStatement ps = conn.prepareStatement(sql);			
			ps.setString(1, product.getProductName());
			ps.setInt(2, product.getPrice());
			ps.setString(3, product.getProductNo());
			ps.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Product> select() {
		String sql="select * from product";
		List<Product> productList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductNo(rs.getString("productNo"));
				product.setProductName(rs.getString("productName"));
				product.setPrice(rs.getInt("price"));
				productList.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return productList;
	}

	@Override
	public List<Product> selectPorductNoList(String productNo) {
		String sql="select * from product where productno=?";
		List<Product> productList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1,productNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Product product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductNo(rs.getString("productNo"));
				product.setProductName(rs.getString("productName"));
				product.setPrice(rs.getInt("price"));
				productList.add(product);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return productList;
	}

	@Override
	public Product selectPorductNo(String productNo) {
		Product product=null;
		String sql="select * from product where productno=?";

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setString(1, productNo);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				product = new Product();
				product.setId(rs.getInt("id"));
				product.setProductNo(rs.getString("productNo"));
				product.setProductName(rs.getString("productName"));
				product.setPrice(rs.getInt("price"));			
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return product;
	}
	
	public static String productList() {
	    String productString="";
		String sql="select productno from product";
		List<Product> productList = new ArrayList();

		try {
			PreparedStatement ps = conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				productString = productString +",sum("+rs.getString("productNo")+") as "+rs.getString("productNo")+" ";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return productString;
	}

	@Override
	public String getNo() {
		String productNo=null;
		String sql ="select CONCAT('p',lpad(max(right(productno,3))+1,3,'0')) as no from product";
		try {
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();			
			if(rs.next())
				productNo = rs.getString("no");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return productNo;
	}

}
