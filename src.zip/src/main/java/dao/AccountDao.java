package dao;

import java.util.List;

import model.Account;

public interface AccountDao {

		void add(Account account);
		
		List<Account> select ();
		Account selectUserName (String userName);
		String selectName (String userName);
		List<Account> selectUserNameList (String userName);
		Account selectUserNamePassword (String userName,String password);
			
		void update(Account account);
	
		void delete(Account account);
		
}
