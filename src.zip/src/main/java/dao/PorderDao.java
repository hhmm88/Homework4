package dao;

import java.util.List;
import java.util.Map;

import model.Porder;

public interface PorderDao {
	
	void insert(Porder porder);
		
	void update(Porder porder);

	void delete(Porder porder);
	

	List<Porder> selectAll();
	Map<String,Integer> selectDetail(String porderNo);
	List<Porder> selectNo(String userName,String porderNo);
    List<Porder> selectUserName(String userName);
    List<Porder> selectDetailAll(String porderNo);
    String getNo();
    //Porder selectPorductNo(String productNo);
}
