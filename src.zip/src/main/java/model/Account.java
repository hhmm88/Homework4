package model;

import java.io.Serializable;

public class Account implements Serializable  {
	private int id;
	private String name;
	private String username;
	private String password;
	private String level;
	
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Account(String name, String username, String password, String level) {
		super();
		this.name = name;
		this.username = username;
		this.password = password;
		this.level = level;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getUserName() {
		return username;
	}


	public void setUserName(String username) {
		this.username = username;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getLevel() {
		return level;
	}


	public void setLevel(String level) {
		this.level = level;
	}
	
	

}
