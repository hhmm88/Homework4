package model;

import java.io.Serializable;
import java.util.Map;

public class Porder implements Serializable {
	private int id;
	private String porderNo;	
	private String userName;
	private Map<String,Integer> productAmount;
	private String productNo;
	
	public Porder() {
		super();
		// TODO Auto-generated constructor stub
		
	}
	
	
	public Porder(String porderNo, String userName) {
		super();
		this.porderNo = porderNo;
		this.userName = userName;
	}


	public String getProductNo() {
		return productNo;
	}
	public void setProductNo(String productNo) {
		this.productNo = productNo;
	}
	private int amount;
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	private int sum;
	
	public int getSum() {
		return sum;
	}
	public void setSum(int sum) {
		this.sum = sum;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getPorderNo() {
		return porderNo;
	}
	public void setPorderNo(String porderNo) {
		this.porderNo = porderNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/*
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}
	
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	*/
	public Map<String, Integer> getProductAmount() {
		return productAmount;
	}
	public void setProductAmount(Map<String, Integer> productAmount) {
		this.productAmount = productAmount;
	}
}
