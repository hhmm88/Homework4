package service;

import java.util.List;

import model.Product;

public interface ProductService {

		boolean insertProduct(Product product);
		
		boolean deleteProduct(Product product);
		
		boolean updateProduct(Product product);
		
		List<Product> selectAll();
		List<Product> selectByPorductNoList(String productNo);
		Product selectByPorductNo(String productNo);
		String getProductNo();
}
