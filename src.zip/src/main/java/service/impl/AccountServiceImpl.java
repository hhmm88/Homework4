package service.impl;

import java.util.List;

import dao.impl.AccountDaoImpl;
import model.Account;
import service.AccountService;

public class AccountServiceImpl implements AccountService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	private static AccountDaoImpl adi = new AccountDaoImpl();

	@Override
	public boolean addAccount(Account account) {
		boolean Insert=false;
		Account a=adi.selectUserName(account.getUserName());
		if(a==null)
		{
			adi.add(account);
			Insert=true;
		}
				
		return Insert;
	}
	@Override
	public Account login(String userName, String password) {
		return adi.selectUserNamePassword(userName, password);
	}
	@Override
	public Account selectByUserName(String userName) {
		return adi.selectUserName(userName);
	}
	@Override
	public List<Account> selectAll() {
		return adi.select();
	}
	@Override
	public List<Account> selectByUserNameList(String userName) {
		return adi.selectUserNameList(userName);
	}
	@Override
	public boolean updateAccount(Account account) {
		Account a=adi.selectUserName(account.getUserName());
		boolean Update=false;
		if(a!=null)
		{
			Update=true;
			a.setPassword(account.getPassword());
			adi.update(account);
		}
		
		return Update;
	}
	@Override
	public boolean deleteAccount(Account account) {
		Account a=adi.selectUserName(account.getUserName());
		boolean Delete=false;
		if(a!=null)
		{
			Delete=true;
			adi.delete(account);
		}
		
		return Delete;
	}
	@Override
	public String selectGetName(String userName) {
		return adi.selectName(userName);
	}
}
