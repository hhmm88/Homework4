package service.impl;

import java.util.List;
import java.util.Map;

import dao.impl.PorderDaoImpl;
import model.Porder;
import service.PorderService;

public class PorderServiceImpl implements PorderService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	private static PorderDaoImpl pdi = new PorderDaoImpl();
	@Override
	public boolean insertPorder(Porder porder) {
		boolean Insert=false;
		try {
			pdi.insert(porder);
			Insert=true;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return Insert;
	}

	@Override
	public boolean updatePorder(Porder porder) {
		boolean Update=false;
		try {
			porder.getUserName();
			porder.getPorderNo();
			porder.getProductAmount();
			pdi.update(porder);
			Update=true;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return Update;
	}

	@Override
	public boolean deletePorder(Porder porder) {
		boolean Delete=false;
		try {
			pdi.delete(porder);
			Delete=true;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return Delete;
	}

	@Override
	public List<Porder> selectPorderAll() {
		
		return pdi.selectAll();
	}

	@Override
	public Map<String, Integer> selectPorderDetail(String porderNo) {
		
		return pdi.selectDetail(porderNo);
	}

	@Override
	public List<Porder> selectByNo(String userName, String porderNo) {

		return pdi.selectNo(userName, porderNo);
	}

	@Override
	public List<Porder> selectByUserName(String userName) {

		return pdi.selectUserName(userName);
	}

	@Override
	public List<Porder> selectPorderDetailAll(String porderNo) {

		return pdi.selectDetailAll(porderNo);
	}

	@Override
	public String getPorderNo() {
		
		return pdi.getNo();
	}

}
