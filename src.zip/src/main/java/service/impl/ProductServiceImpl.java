package service.impl;

import java.util.List;

import dao.impl.AccountDaoImpl;
import dao.impl.ProductDaoImpl;
import model.Account;
import model.Product;
import service.ProductService;

public class ProductServiceImpl implements ProductService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Product a = new Product();
		a.setProductName("pp");
		a.setPrice(22222);
		a.setProductNo("p002");
		new ProductServiceImpl().updateProduct(a);
*/
	}

	private static ProductDaoImpl pdi = new ProductDaoImpl();
	@Override
	public boolean insertProduct(Product product) {
		boolean Insert=false;
		try {
			pdi.insert(product);
			Insert=true;
		}
		catch (Exception e) {
			e.printStackTrace();
		}
				
		return Insert;
	}

	@Override
	public boolean deleteProduct(Product product) {
		//Product p=pdi.selectPorductNo(product.getProductName());
		boolean Delete=false;
		try {
			Delete=true;
			pdi.delete(product);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return Delete;
	}

	@Override
	public boolean updateProduct(Product product) {
		//Product p=pdi.selectPorductNo(product.getProductName());
		boolean Update=false;
		try {
			Update=true;
			product.getProductNo();
			product.getProductName();
			product.getPrice();
			pdi.update(product);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		return Update;
	}

	@Override
	public List<Product> selectAll() {
		// TODO Auto-generated method stub
		return  pdi.select();
	}

	@Override
	public List<Product> selectByPorductNoList(String productNo) {
		// TODO Auto-generated method stub
		return pdi.selectPorductNoList(productNo);
	}

	@Override
	public Product selectByPorductNo(String productNo) {
		// TODO Auto-generated method stub
		return pdi.selectPorductNo(productNo);
	}

	@Override
	public String getProductNo() {
		// TODO Auto-generated method stub
		return pdi.getNo();
	}

}
