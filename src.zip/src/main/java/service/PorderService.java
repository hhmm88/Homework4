package service;

import java.util.List;
import java.util.Map;

import model.Porder;

public interface PorderService {
	
	boolean insertPorder(Porder porder);
	
	boolean updatePorder(Porder porder);

	boolean deletePorder(Porder porder);
	

	List<Porder> selectPorderAll();
	Map<String,Integer> selectPorderDetail(String porderNo);
	List<Porder> selectByNo(String userName,String porderNo);
    List<Porder> selectByUserName(String userName);
    List<Porder> selectPorderDetailAll(String porderNo);
    String getPorderNo();

}
