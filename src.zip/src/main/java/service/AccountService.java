package service;

import java.util.List;

import model.Account;

public interface AccountService {

	boolean addAccount(Account account);
	
	Account login(String UserName,String password);
	Account selectByUserName(String userName);
	String selectGetName(String userName);
	List<Account> selectAll();
	List<Account> selectByUserNameList(String userName);
	
	boolean updateAccount(Account account);
	
	boolean deleteAccount(Account account);
}
